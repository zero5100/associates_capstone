-- phpMyAdmin SQL Dump
-- version 3.3.2deb1ubuntu1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 14, 2012 at 05:02 PM
-- Server version: 5.1.63
-- PHP Version: 5.3.2-1ubuntu4.15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `capstone`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`groupid`, `groupname`, `description`) VALUES
(1, 'Figurehead', 'Boy howdy databases are super cool'),
(7, 'Losers', 'We make programs and get in fights'),
(8, 'Mathematicians', 'This group is dedicated to   writing software dealing with math.'),
(9, 'Farmers', 'A group revolving around computers in farms.'),
(10, 'Librarians', 'A group focused on sorting algorithms.'),
(11, 'Gamers', 'We love video games!'),
(12, 'Horror Fans', 'Fans of horror unite for programming.'),
(13, 'History Buffs', 'Program yourself into the past.'),
(14, 'Artists', 'Make programming beautiful.'),
(15, 'Landowners', 'Make owning property easier with computers.'),
(16, 'Students', 'We are always looking for a way to make school better.'),
(17, 'Teachers', 'Professionally trying to make school a better learning environment.');

-- --------------------------------------------------------

--
-- Table structure for table `g_artists`
--

CREATE TABLE IF NOT EXISTS `g_artists` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `g_artists`
--

INSERT INTO `g_artists` (`index`, `projectid`) VALUES
(1, 35),
(2, 36),
(3, 37);

-- --------------------------------------------------------

--
-- Table structure for table `g_farmers`
--

CREATE TABLE IF NOT EXISTS `g_farmers` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `g_farmers`
--

INSERT INTO `g_farmers` (`index`, `projectid`) VALUES
(1, 35),
(2, 42),
(3, 43),
(4, 44);

-- --------------------------------------------------------

--
-- Table structure for table `g_figurehead`
--

CREATE TABLE IF NOT EXISTS `g_figurehead` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `g_figurehead`
--


-- --------------------------------------------------------

--
-- Table structure for table `g_gamers`
--

CREATE TABLE IF NOT EXISTS `g_gamers` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `g_gamers`
--

INSERT INTO `g_gamers` (`index`, `projectid`) VALUES
(1, 28),
(2, 40);

-- --------------------------------------------------------

--
-- Table structure for table `g_history buffs`
--

CREATE TABLE IF NOT EXISTS `g_history buffs` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `g_history buffs`
--

INSERT INTO `g_history buffs` (`index`, `projectid`) VALUES
(1, 32),
(2, 34);

-- --------------------------------------------------------

--
-- Table structure for table `g_horror fans`
--

CREATE TABLE IF NOT EXISTS `g_horror fans` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `g_horror fans`
--

INSERT INTO `g_horror fans` (`index`, `projectid`) VALUES
(1, 28),
(2, 29),
(3, 30);

-- --------------------------------------------------------

--
-- Table structure for table `g_landowners`
--

CREATE TABLE IF NOT EXISTS `g_landowners` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `g_landowners`
--

INSERT INTO `g_landowners` (`index`, `projectid`) VALUES
(1, 38),
(2, 39);

-- --------------------------------------------------------

--
-- Table structure for table `g_librarians`
--

CREATE TABLE IF NOT EXISTS `g_librarians` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `g_librarians`
--

INSERT INTO `g_librarians` (`index`, `projectid`) VALUES
(1, 24),
(2, 27),
(3, 33);

-- --------------------------------------------------------

--
-- Table structure for table `g_losers`
--

CREATE TABLE IF NOT EXISTS `g_losers` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `g_losers`
--


-- --------------------------------------------------------

--
-- Table structure for table `g_mathematicians`
--

CREATE TABLE IF NOT EXISTS `g_mathematicians` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `g_mathematicians`
--

INSERT INTO `g_mathematicians` (`index`, `projectid`) VALUES
(1, 19),
(2, 20),
(3, 31);

-- --------------------------------------------------------

--
-- Table structure for table `g_students`
--

CREATE TABLE IF NOT EXISTS `g_students` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `g_students`
--

INSERT INTO `g_students` (`index`, `projectid`) VALUES
(1, 24),
(2, 25),
(3, 26),
(4, 41);

-- --------------------------------------------------------

--
-- Table structure for table `g_teachers`
--

CREATE TABLE IF NOT EXISTS `g_teachers` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL,
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `g_teachers`
--

INSERT INTO `g_teachers` (`index`, `projectid`) VALUES
(1, 21),
(2, 23),
(3, 22);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `projectid` int(11) NOT NULL AUTO_INCREMENT,
  `projectname` text NOT NULL,
  `hash` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`projectid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`projectid`, `projectname`, `hash`, `description`) VALUES
(24, 'Library Database GUI', '*0686E67FDA94F9F0D0310D8E8E4A67A916800A01', 'Make an easy to use GUI to find any book in the library.'),
(21, 'Student Roster', '*211CC4BEBB7B7FD9F0355B72F928ECD6A5E886F8', 'Keep track of kids and their grades'),
(22, 'Attendance Sheet', '*171EBEEE15F2459BB79B4AE89C2D258F2F4AA839', 'Shows which students were in class.'),
(23, 'Weekly Planner', '*47DB4DB57424BC317028B0479F11E35DEEB2B99A', 'Easily plan each week of class.'),
(26, 'Student Scheduler', '*A6E88972D1C4997217872B52DBEC854BCCCD5D75', 'Help other students find out which classes to take with which teacher.'),
(27, 'Checkout List', '*3E7B7A619A74B2178A058AE0CD8C7E1E4E5F396E', 'Keep track of which books are checked out of the library.'),
(25, 'Yearbook Organizer', '*86A3A9BEE0747973D15BD0C0919D9E8650693DC3', 'Store and sort pictures for the yearbook.'),
(19, 'Binary Calculator', '*3F4F46796AEB28A2019C23D271398928B80FCCD9', 'A simple calculator that  adds in binary and converts to binary.'),
(48, 'Pounds To Kilograms', '*DE74CD08AB8072A10870538470BD2A9D874C5BF5', 'It converts pounds to kilograms!'),
(20, 'Hexadecimal Calculator', '*A2F9E7B6066535DF12F67510D678EE44A3C6B642', 'Calculates in hexadecimal format.'),
(28, 'Horror Games', '*2EF5F700A0FDE8B6842EDF12D48C5B25BF8E7912', 'Make better horror games!'),
(29, 'Haunted House', '*DB12963C3E769D638191437E1FBA7F61CB40C2F6', 'Create a fun haunted house interactive program.'),
(30, 'Horror Ranking', '*6D646D6023B1880C5C473C9B946F5DA758BCF15E', 'Rank horror movies based on scariness.'),
(31, 'Simple Algorithm Calculator', '*E7BC8D6AD600740BF1879BDBF2BB0122DA6DE76A', 'Have a program that can compute simple algoritms such as volume and mass.'),
(32, 'Years of War', '*68D8FDA804FA80E5D5851ABC0D166F8E9A3294EC', 'Show what wars were in what year in an easy to use app.'),
(33, 'Book Sale', '*42052774A7909D9470F8CFC5C7B00E6D1BCF4DB5', 'Keep track of what books were sold and how much was raised.'),
(34, 'Royal Families', '*39DD726F3AB1ED980745EC01E3FB14EFFDB6BB02', 'Track the lineage of royal blood.'),
(35, 'Art on the Farm', '*9ABA2EEFF8A96093DA7141FA0B1BCAC9C315F362', 'Keep track of what art is sold in the farm fund raiser.'),
(36, 'Art Catalogue', '*E2149D2C92E47CA64464CEA1B478C954BAB39448', 'Keep a current list of all pieces done by the group.'),
(37, 'Artist of the Month', '*9161E591FF80BEDAD2BA755748AB6651127465B6', 'Users vote and tally up a poll on who should be artist of the month.'),
(38, 'House Simulator', '*AE4B68F527ADD1CC1949738040893FA531335FF5', 'Create realistic sims of current houses.'),
(39, 'Sales Transactions', '*934904CFC792B4D528B1B3D54223310400312118', 'Keep a current database on all land bought and sold.'),
(40, 'Trade Collection', '*3C7A12C3268B1DF2FE5915464A25B49D1CFDD535', 'Find out what games people are selling or want to buy.'),
(41, 'Tutoring', '*152DA78D4662B56CC5D7CEF06CB0B67C38AC9249', 'Keep a list of who can tutor which subjects.'),
(42, 'Crops', '*F3F82C9554A36B947CC6C0969CDD596197CC1A56', 'Keep track of what each farmer is planting and work together to be efficient.'),
(43, 'Livestock', '*0F1A472B792603B17E33B815A528C6D9A923BF1C', 'Keep track of which farm has what livestock.'),
(44, 'Livestock Show', '*27519B5D76432DF6E23C3128A1A46F0D2DAFF11A', 'Get a list of all the livestock that will be presented in the farm show.');

-- --------------------------------------------------------

--
-- Table structure for table `p_art catalogue`
--

CREATE TABLE IF NOT EXISTS `p_art catalogue` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `p_art catalogue`
--

INSERT INTO `p_art catalogue` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 0, '2010-08-26', '11:15:22', 'Reported', 'New artists cannot be added to the group.', 'LeArtist', NULL, NULL),
(2, 'Error', 1024, '2010-08-13', '10:24:08', 'Open', 'Certain works of art cannot be displayed.', NULL, NULL, 'A fix is being looked in to.'),
(3, 'Error', 555, '2010-08-16', '12:12:12', 'Open', 'Program only displays up to five works by any given artist.', NULL, NULL, 'Limit will be taken off of display maximum.');

-- --------------------------------------------------------

--
-- Table structure for table `p_artist of the month`
--

CREATE TABLE IF NOT EXISTS `p_artist of the month` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `p_artist of the month`
--

INSERT INTO `p_artist of the month` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'Error', 1024, '2010-08-12', '15:18:22', 'Closed', 'Artist of the Month does not keep records of previous artists of the month.', NULL, NULL, 'Added the ability to store previous artists.'),
(2, 'User', 0, '2010-08-16', '07:22:15', 'Open', 'Artists are listed in inappropriate order.', 'MadameArtist', NULL, 'A fix is being looked in to.'),
(3, 'User', 0, '2010-08-13', '06:15:51', 'Open', 'There are 13 months in a year.', 'MadameArtist', 'Last I checked, there were only 12.', 'The 13th is invisible and is being used to store some information for now. A fix will be implemented in due time.');

-- --------------------------------------------------------

--
-- Table structure for table `p_art on the farm`
--

CREATE TABLE IF NOT EXISTS `p_art on the farm` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `p_art on the farm`
--

INSERT INTO `p_art on the farm` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 0, '2010-08-30', '00:25:36', 'Reported', 'Art is being sold twice.', 'Jimbobby', 'It''s saying that my original work "Pig on Farm" is being sold twice, when there is only one.', NULL),
(2, 'User', 0, '2010-08-29', '12:55:12', 'Open', 'Problem with registering new patrons.', 'Jimbobby', NULL, 'Functionality for adding new users will be added soon.'),
(3, 'Error', 318, '2010-08-17', '06:55:12', 'Closed', 'Issue with removing art from list after it is sold.', NULL, NULL, 'Delete function was added to remove sold art from the list.'),
(4, 'User', 0, '2010-08-17', '15:55:36', 'Open', 'User log in wont work for users registered after 07/01/10', 'WackyWally', 'Some of my employees can''t register to maintain the program.', 'A fix is being looked in to. For the mean time, refer to your administrator to manually add new members.');

-- --------------------------------------------------------

--
-- Table structure for table `p_attendance sheet`
--

CREATE TABLE IF NOT EXISTS `p_attendance sheet` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `p_attendance sheet`
--

INSERT INTO `p_attendance sheet` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 1234, '2010-08-15', '12:52:36', 'Reported', 'Program only holds up to 35 students.', 'AnneMick', 'The program won''t hold more than 35 students.', NULL),
(2, 'User', 1024, '2010-08-25', '08:14:32', 'Open', 'Data won''t save when more than five students are absent in any given instance.', 'JaneDoes', 'I can''t save anything if more than five students are absent.', 'Fix will probably involve changing some variable types in the main form.'),
(3, 'Error', 318, '2010-08-26', '10:32:00', 'Open', 'Switching order of the students can overwrite student information.', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `p_binary calculator`
--

CREATE TABLE IF NOT EXISTS `p_binary calculator` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `p_binary calculator`
--

INSERT INTO `p_binary calculator` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(23, 'Error', 1234, '2010-08-05', '11:35:22', 'Open', 'The program crashes if the first number is a 0.', NULL, NULL, ''),
(24, 'User', 0, '2010-08-12', '12:23:22', 'Closed', 'The program crashes if a letter is entered.', 'AdamSmith', 'I entered in a w by accident and the system crashed.', ''),
(26, 'User', 0, '2010-08-31', '10:00:20', 'Closed', 'The program crashes if the user presses the x.', 'JaneDoes', 'I tried exiting the program through the x button and it crashed.', 'I tried exiting the program through the x button and it crashed.');

-- --------------------------------------------------------

--
-- Table structure for table `p_book sale`
--

CREATE TABLE IF NOT EXISTS `p_book sale` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `p_book sale`
--

INSERT INTO `p_book sale` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 318, '2010-08-11', '04:55:06', 'Closed', 'If more than $100 is sold of any one book, the total is reset to $0.', 'Broonhilda', 'Our best sellers are selling no more than $100.', 'The amount of money tallied was increased.'),
(2, 'User', 153, '2010-08-23', '12:15:15', 'Open', 'Program does not register when a book is out of stock.', 'Tarrasque', 'If a book is out of stock, it isn''t taken off of the list.', 'A fix is being worked on.'),
(3, 'Error', 3333, '2010-08-06', '10:18:22', 'Reported', 'Type of book is showing up in the wrong field.', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_checkout list`
--

CREATE TABLE IF NOT EXISTS `p_checkout list` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=235 ;

--
-- Dumping data for table `p_checkout list`
--

INSERT INTO `p_checkout list` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 333, '2010-08-24', '18:55:48', 'Closed', 'Books returned after due date continue to accrue late fees.', 'Balinda Kapsten', 'One poor soul owes the library over $300.', 'Modified the code to delete the instance from the database.'),
(2, 'User', 122, '2010-08-10', '09:45:36', 'Open', 'If someone has more than one overdue book, it doubles or triples the amount they owe per book.', 'Geoffry Bluth', 'The charges should be $.10 per day per book, not $.10 per day per book PER book.', 'Modification to the algorithm that calculates overdue fines will be completed soon.'),
(3, 'User', 313, '2010-08-26', '12:12:13', 'Closed', 'Tracking books works improperly when a book is checked out twice by the same person.', 'Kathryn Kompe', 'If a person comes in and rechecks out a book, the system seems to lose it.', 'Thats not a problem.'),
(22, 'Error', 88, '1993-06-22', '14:22:21', 'Open', 'The sorting algorithm doesn''t work if the current date ends in 0.', NULL, NULL, NULL),
(77, 'Error', 666, '2002-04-17', '00:00:00', 'Closed', 'The clock does not reset when the day is over, and the date in the program doesn''t increment.', NULL, NULL, 'Fixed.'),
(234, 'User', 2, '2007-01-03', '15:32:11', 'Reported', 'Users are fined the amount of books they have checked out, even if they only have one late book.', 'Meg Griffin', 'I was fined for ten books, even though only two were late.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_crops`
--

CREATE TABLE IF NOT EXISTS `p_crops` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `p_crops`
--

INSERT INTO `p_crops` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(83, 'User', 9323, '2001-02-06', '19:45:22', 'Closed', 'Program is limited to only crops grown in the area.', 'Joleen', 'I would like to use this program down in Ohio.', 'Made separate project for different region.'),
(3, 'Error', 46, '2010-08-04', '18:12:01', 'Reported', 'Ranges of crops do not accept numbers smaller than the first.', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_haunted house`
--

CREATE TABLE IF NOT EXISTS `p_haunted house` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `p_haunted house`
--

INSERT INTO `p_haunted house` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'Error', 141, '2010-08-25', '19:17:44', 'Reported', 'Ghost continue to spawn in the coat room, until visibility is reduced to 0.', NULL, NULL, NULL),
(2, 'User', 414, '2010-08-23', '15:34:50', 'Reported', 'The dolls in the little girl''s room flash random colors.', 'Tim Tonsils', 'The dolls keep turning green and pink and yellow. It isn''t very scary.', NULL),
(3, 'User', 513, '2010-08-17', '23:15:22', 'Closed', 'The mirrors don''t show the character''s reflection.', 'ClintEastwoodRulz', 'Some kind of animal keeps appearing when I look into the mirror.', 'It''s supposed to do that. It''s a werewolf. Closed.'),
(4, 'Error', 318, '2010-08-09', '15:12:48', 'Open', 'The headless man walks with an unrealistic exaggerated limp.', NULL, NULL, 'The animation is currently being worked on to smooth out the walk.');

-- --------------------------------------------------------

--
-- Table structure for table `p_hexadecimal calculator`
--

CREATE TABLE IF NOT EXISTS `p_hexadecimal calculator` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `p_hexadecimal calculator`
--

INSERT INTO `p_hexadecimal calculator` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'Error', 555, '2010-08-17', '18:56:22', 'Reported', 'Program crashes when a hexidecimal number is put in for converting.', NULL, NULL, NULL),
(2, 'User', 444, '2010-08-26', '10:12:14', 'Open', 'Hexidecimal does not convert to binary properly.', 'Sam Calculator', 'Certain numbers don''t properly convert to binary.', 'A fix is being looked in to.'),
(3, 'User', 1034, '2010-08-23', '05:45:00', 'Closed', 'Program crashes when logarithm button is pressed.', 'Sam Calculator', 'The logarithm function doesn''t work.', 'A typo was fixed in the code to fix the logarithm function.'),
(4, 'User', 1005, '2010-08-16', '15:15:49', 'Reported', 'Base 10 numbers convert to hexadecimal improperly.', 'Jim Stoney', 'The base 10 number I put in comes back as hexadecimal + 1.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_horror games`
--

CREATE TABLE IF NOT EXISTS `p_horror games` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `p_horror games`
--

INSERT INTO `p_horror games` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 1024, '2010-08-23', '12:45:15', 'Open', 'Player falls through the level on the Haunted House level of "Scared by Ghoulies".', 'The Amazing Rambo', 'When you go into the master bedroom, by the foot of the bed, you fall through the level if you open the chest.', 'A patch is currently being worked on to fix this and additional issues.'),
(2, 'User', 784, '2010-08-16', '14:52:59', 'Closed', 'The meat hook kills enemies in one hit on the game "Scared by Ghoulies".', 'Harry Horror', 'I love one shotting stuff, but it kind of ruins the game, doesn''t it?', 'We decreased the damage output on this, and several other weapons.'),
(3, 'Error', 1104, '2010-08-30', '18:55:12', 'Reported', 'Players are exploiting a bug in "The World of Terror" that allows them to trade items for gold and retain the item.', NULL, NULL, NULL),
(4, 'User', 12, '2010-08-15', '08:45:30', 'Open', 'Players can fly through levels after exiting water, while wearing the slippers of courage.', 'Terry Urbolg', 'The slippers of courage allow players to fly to areas they shouldn''t be able to get to yet.', 'An issue with the physics engine is causing the character to retain the ability to swim after exiting the water.'),
(5, 'Error', 1000, '2010-08-24', '07:36:12', 'Reported', 'Jack''o''lantern lantern''s continue to produce light after they are unequipped. ', NULL, NULL, NULL),
(6, 'User', 1212, '2010-08-26', '14:55:16', 'Reported', 'Players cannot progress past the Wheel of Terror if they fail after one attempt.', 'Harold Hardy', 'I lost against the headless horseman, and now I can''t play any more.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_horror ranking`
--

CREATE TABLE IF NOT EXISTS `p_horror ranking` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `p_horror ranking`
--

INSERT INTO `p_horror ranking` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'Error', 1024, '2010-08-17', '06:23:15', 'Closed', 'Movies ranked on suspense have less weight than those based on shock value.', NULL, NULL, 'The rating system was revised to even out all of the different types of horror.'),
(2, 'User', 538, '2010-08-18', '18:45:44', 'Reported', 'Movies cannot be sorted by ascending order.', 'VigoRous', 'The movies are listed in random order, and I can''t search them by alphabetical order.', NULL),
(3, 'Error', 519, '2010-08-02', '15:34:50', 'Closed', 'Movies do not display how many stars they were rated.', NULL, NULL, 'Code was added to display stars based on rating/10');

-- --------------------------------------------------------

--
-- Table structure for table `p_house simulator`
--

CREATE TABLE IF NOT EXISTS `p_house simulator` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `p_house simulator`
--

INSERT INTO `p_house simulator` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 0, '2010-08-03', '02:44:12', 'Closed', 'Walls occasionally disappear.', 'CaptainofIndustry', 'Some times the walls will become transparent.', 'A fix was made in the transparency editor to fix this issue.'),
(2, 'Error', 1024, '2010-08-26', '12:15:22', 'Closed', 'Decorations hanging on walls appear upside down.', NULL, NULL, 'This issue has been resolved.'),
(3, 'User', 0, '2010-08-22', '15:15:12', 'Reported', 'Carpeting cannot be changed as previously explained.', 'TildeTammy', NULL, NULL),
(4, 'User', 0, '2010-08-01', '12:35:22', 'Open', 'Lighting does not affect the north wall properly.', 'GregoryRalds', NULL, 'An issue with the physics engine is affecting natural and artificial light.');

-- --------------------------------------------------------

--
-- Table structure for table `p_library database gui`
--

CREATE TABLE IF NOT EXISTS `p_library database gui` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `p_library database gui`
--

INSERT INTO `p_library database gui` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 318, '2010-08-03', '16:25:36', 'Closed', 'Doesn''t return all search results.', 'Jim Duffy', 'Searching by Author only brings up the first 10 books that the Author wrote.', 'Added function to remove maximum search result limit.'),
(2, 'User', 887, '2010-08-11', '14:23:42', 'Open', 'Books that start with the same word show up as the same book.', 'Seth Strange', 'All of the Harry Potter books are the Chamber of Secrets.', 'A solution is being looked in to.'),
(3, 'User', 404, '2010-08-11', '12:14:15', 'Closed', 'User data remains logged in after user logs out', 'Tim Little', 'I can''t log out of the program.', 'Fixed the destructor.'),
(4, 'Error', 809, '2010-08-16', '00:00:00', 'Open', 'Bug will make system crash when user selects three or more books from different authors.', '', '', ''),
(5, 'User', 1366, '2010-08-18', '10:13:45', 'Reported', '"Add to List" function will not display with certain users.', 'Mr. Curator', 'Several of our members have complained about not being able to view their lists.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_livestock`
--

CREATE TABLE IF NOT EXISTS `p_livestock` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=94 ;

--
-- Dumping data for table `p_livestock`
--

INSERT INTO `p_livestock` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(93, 'Error', 20, '1999-06-24', '21:33:22', 'Open', 'Gives an error message on exit of program.', NULL, NULL, NULL),
(3, 'User', 92, '1998-11-27', '04:33:13', 'Reported', 'Only ten people can be added to the users list.', 'Ray C.', NULL, 'Added additional room in the table.');

-- --------------------------------------------------------

--
-- Table structure for table `p_livestock show`
--

CREATE TABLE IF NOT EXISTS `p_livestock show` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8484849 ;

--
-- Dumping data for table `p_livestock show`
--

INSERT INTO `p_livestock show` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(8484848, 'Error', 12, '2003-11-11', '11:11:11', 'Reported', 'The amount of livestock per person cannot exceed 20.', NULL, NULL, 'Why do you have so many chickens?'),
(87, 'User', 333, '2001-07-07', '03:21:34', 'Open', 'The types of cows and chickens are messed up in the tables.', 'Lee Joe', 'The table only gives options for cattle as types of chickens.', NULL),
(199, 'User', 4, '2010-08-03', '07:55:32', 'Closed', 'Rabbits cannot be added to the livestock.', 'George Takei', NULL, 'Added a table under livestock.');

-- --------------------------------------------------------

--
-- Table structure for table `p_pounds to kilograms`
--

CREATE TABLE IF NOT EXISTS `p_pounds to kilograms` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `p_pounds to kilograms`
--

INSERT INTO `p_pounds to kilograms` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'Error', 100, '2010-08-31', '14:48:40', 'Closed', 'java.lang.NumberFormatException: For input string: "apple"', NULL, NULL, 'HI.'),
(2, 'User', 0, '2010-08-31', '14:52:15', 'Closed', 'It dont work right!', 'huskies15', NULL, 'it sure does!');

-- --------------------------------------------------------

--
-- Table structure for table `p_royal families`
--

CREATE TABLE IF NOT EXISTS `p_royal families` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `p_royal families`
--

INSERT INTO `p_royal families` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'Error', 691, '2010-08-10', '13:44:18', 'Open', 'Tracking royalty from Denmark always returns with English Royalty.', NULL, NULL, 'A fix is being looked in to.'),
(2, 'User', 0, '2010-08-18', '02:15:59', 'Reported', 'Program is displaying impossible lineage.', 'FredmanFred', 'It''s saying that I am related to Attila the Hun and Joan of Arc, and I''m from Spain.', NULL),
(3, 'User', 0, '2010-08-24', '03:18:22', 'Open', 'Ancestors are showing up as coming from the future.', 'Unity', 'My great grandmother was not born in 2032.', 'A problem with the years certain people were born in is being fixed.'),
(4, 'Error', 352, '2010-08-16', '17:55:21', 'Open', 'People with no information on their family lineage are getting random ancestors.', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_sales transactions`
--

CREATE TABLE IF NOT EXISTS `p_sales transactions` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `p_sales transactions`
--

INSERT INTO `p_sales transactions` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 0, '2010-08-12', '12:34:09', 'Closed', 'Program does not convert $ per acre properly.', 'Yetti', 'It won''t show me how much money I am making per acre.', 'The calculation to return this result was fixed.'),
(2, 'Error', 318, '2010-08-23', '12:36:18', 'Reported', 'Sales are not being saved properly.', NULL, NULL, 'A fix in the database is required.'),
(3, 'Error', 555, '2010-08-22', '12:18:32', 'Open', 'Resizing the window rearranges components.', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_simple algorithm calculator`
--

CREATE TABLE IF NOT EXISTS `p_simple algorithm calculator` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `p_simple algorithm calculator`
--

INSERT INTO `p_simple algorithm calculator` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 1024, '2010-08-17', '05:12:55', 'Closed', 'Answers return with additional number added to the end.', 'Mathamator', 'The answers come back properly, but there are always extra numbers added at the end.', 'Code was changed to remove any extra information added after the answer is returned.'),
(2, 'Error', 419, '2010-08-17', '10:52:55', 'Open', 'The program doesn''t allow multiple algorithms to be processed in a single instance.', NULL, NULL, 'A fix is being worked on.'),
(3, 'User', 639, '2010-08-16', '11:56:04', 'Reported', 'The calculator cannot be resized.', 'MorayEel', 'I need to resize the window to see my entire answer.', NULL),
(4, 'User', 881, '2010-08-16', '12:39:08', 'Open', 'Program ends unexpectedly after being opened for too long.', 'Trent', 'If I run the program all day at my desk, I have to restart it 4 or 5 times.', 'A function was added to require log in if program hasn''t been used in over 45 minutes.'),
(5, 'User', 313, '2010-08-27', '21:28:30', 'Reported', 'Closing program with the x button doesn''t work.', 'Trixxie', 'I''m used to closing stuff with the x button, and I can''t do that with this program.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_student roster`
--

CREATE TABLE IF NOT EXISTS `p_student roster` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `p_student roster`
--

INSERT INTO `p_student roster` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(14, 'User', 1134, '2010-08-05', '14:35:01', 'Closed', 'Students grades are lost when the "Update" button is hit', 'Mrs. Lefouff', 'This program won''t let me put in my student''s grades!', 'Fixed the code to properly save the user input.'),
(17, 'User', 404, '2010-08-26', '12:52:36', 'Reported', 'Teachers cannot insert grades higher than 100%.', 'Mr. Jones', 'Extra credit doesn''t mesh with this program very well.', NULL),
(23, 'Error', 187, '2010-08-24', '10:32:15', 'Reported', '"Exit Program" button doesn''t work.', NULL, NULL, NULL),
(45, 'User', 801, '2010-08-17', '09:43:59', 'Closed', 'Mouse skips over screen for no apparent reason.', 'Chad Wick', 'I can''t click on anything because my mouse keeps disappearing.', 'One of the developers thought it would be funny to add hidden mouse listeners to mess with the clients. He''s looking for new work.'),
(47, 'User', 415, '2010-08-19', '07:30:42', 'Open', 'Program becomes non-responsive when too many grades are added at once.', 'Chad Wick', 'I can''t add all of my students grades at once, or my computer locks up for a couple minutes.', 'Try increasing memory allocation to the multithreading function.'),
(53, 'Error', 813, '2010-08-17', '08:45:32', 'Reported', 'Cannot create new students. Data cannot be stored properly in relation to this problem.', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_student scheduler`
--

CREATE TABLE IF NOT EXISTS `p_student scheduler` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `p_student scheduler`
--

INSERT INTO `p_student scheduler` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'Error', 435, '2010-08-10', '13:04:56', 'Reported', 'Scheduler seems to ignore times that a student cannot attend classes.', NULL, NULL, NULL),
(2, 'User', 1134, '2010-08-18', '14:23:45', 'Reported', 'Certain teachers are favored above others for selecting students.', 'Cindy Lou', 'One of our teachers has 40 students in his class, while another who is teaching the same thing at the same time has 5 students.', NULL),
(3, 'Error', 1143, '2010-08-23', '15:55:17', 'Reported', 'Teachers are showing up for classes that they don''t teach.', NULL, NULL, NULL),
(4, 'User', 302, '2010-08-05', '06:32:00', 'Closed', 'Students can end up taking 50 or more credits worth of classes in one semester.', 'Becky Jameson.', 'Students can enroll in all classes that we offer.', 'Put a limit on the number of credits students can have without extra authorization.');

-- --------------------------------------------------------

--
-- Table structure for table `p_trade collection`
--

CREATE TABLE IF NOT EXISTS `p_trade collection` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `p_trade collection`
--

INSERT INTO `p_trade collection` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 0, '2010-08-16', '15:15:58', 'Closed', 'Top sellers are showing at the bottom of the list.', 'GameMcFly', NULL, 'The sorting function was readjusted properly.'),
(2, 'User', 0, '2010-08-17', '08:12:12', 'Open', 'Games that sell over 1000000 copies are deleted from the table.', 'GameMcFly', 'Halo isn''t showing up any more.', NULL),
(3, 'User', 0, '2010-08-30', '05:33:14', 'Reported', 'User''s wish lists do not refresh every day.', 'GameMcFly', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_tutoring`
--

CREATE TABLE IF NOT EXISTS `p_tutoring` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `p_tutoring`
--

INSERT INTO `p_tutoring` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'Error', 318, '2010-08-17', '15:15:15', 'Open', 'Tutors who can teach three or more subjects are not being scheduled.', NULL, NULL, 'A solution is being looked in to.'),
(2, 'Error', 1024, '2010-08-24', '11:55:18', 'Open', 'Tutors are being scheduled for more than one student at a time.', NULL, NULL, 'A change in the priorities needs to be made.'),
(3, 'Error', 1024, '2010-08-19', '12:22:36', 'Closed', 'New students cannot be scheduled.', NULL, NULL, 'Solution has been implemented.'),
(4, 'Error', 1024, '2010-08-30', '15:15:12', 'Reported', 'Tutors who aren''t tutoring any more cannot be deleted.', NULL, NULL, NULL),
(5, 'Error', 318, '2010-08-25', '14:25:36', 'Open', 'Tutors cannot tutor more than 2 days a week.', NULL, NULL, 'Need to increase the number of times a tutor can teach per week.'),
(6, 'Error', 1024, '2010-08-15', '08:30:00', 'Closed', 'Unknown error is causing the program to crash.', NULL, NULL, 'We need to find a reason for this.');

-- --------------------------------------------------------

--
-- Table structure for table `p_weekly planner`
--

CREATE TABLE IF NOT EXISTS `p_weekly planner` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `p_weekly planner`
--

INSERT INTO `p_weekly planner` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 222, '2010-08-19', '11:15:32', 'Open', 'Week has a hidden 8th day.', 'JimmyJohn', 'What is the 8th day called? Schmunday?', NULL),
(2, 'User', 321, '2010-08-25', '18:52:44', 'Closed', 'User cannot plan more than 3 things in a given day.', 'Christoph', 'What about my busy days?', 'Removed limit on number of activities in a day.'),
(3, 'Error', 453, '2010-08-24', '04:53:52', 'Reported', 'Loss of data after 3 weeks of opening plan.', NULL, NULL, NULL),
(4, 'User', 1024, '2010-08-19', '11:11:14', 'Closed', 'Planner birthday function appears every day.', 'Christoph', 'My birthday is in June, not every day!', 'Problem with setBirthday() fixed.');

-- --------------------------------------------------------

--
-- Table structure for table `p_yearbook organizer`
--

CREATE TABLE IF NOT EXISTS `p_yearbook organizer` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `p_yearbook organizer`
--

INSERT INTO `p_yearbook organizer` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 1320, '2010-08-24', '10:23:55', 'Reported', 'Pictures are replaced by other pictures.', 'Mary Sue', 'When I click on a picture, it turns into a different picture.', NULL),
(2, 'User', 551, '2010-08-18', '15:23:56', 'Closed', 'Club Pictures are mixed in with other club pictures.', 'David Davidson', 'All of the club pictures are messed up', 'We reorganized the file structure for picture saving.'),
(3, 'Error', 543, '2010-08-17', '08:15:36', 'Reported', 'File not found errors.', NULL, NULL, NULL),
(4, 'Error', 648, '2010-08-25', '14:54:39', 'Reported', 'Pictures saving to inappropriate paths.', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `p_years of war`
--

CREATE TABLE IF NOT EXISTS `p_years of war` (
  `bugid` int(11) NOT NULL AUTO_INCREMENT,
  `bugtype` text NOT NULL,
  `errorcode` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` text NOT NULL,
  `description` text,
  `username` text,
  `usercomment` text,
  `devcomment` text,
  PRIMARY KEY (`bugid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4550 ;

--
-- Dumping data for table `p_years of war`
--

INSERT INTO `p_years of war` (`bugid`, `bugtype`, `errorcode`, `date`, `time`, `status`, `description`, `username`, `usercomment`, `devcomment`) VALUES
(1, 'User', 1024, '2010-08-10', '18:45:44', 'Open', 'War of 1812 occurs in wrong range of years.', 'Yononna', 'The war of 1812 did not happen in 1983.', 'A simple change to the database will fix this issue.'),
(2, 'User', 355, '2010-08-14', '17:22:54', 'Open', 'Every war by America comes up as Vietnam.', 'TrayBlaster', 'America has been in wars besides Vietnam.', 'We need to change the associations with America.'),
(101, 'Error', 554, '2000-05-09', '16:33:11', 'Closed', 'A negative year causes the system to crash.', '', NULL, 'Set a check to make sure no - were present.\r\n'),
(102, 'Error', 625, '2010-08-24', '10:23:55', 'Reported', 'China''s wars start in the 1400''s, and doesn''t have information on wars before then.', 'Jim', NULL, NULL),
(4545, 'Error', 999, '2007-12-26', '23:59:59', 'Open', 'The system crashes if the years are not formatted correctly.', 'Yoki ', NULL, NULL),
(4546, 'User', 813, '2010-08-22', '16:22:45', 'Closed', 'Years B.C. come back as years A.D.', 'RandySavage', NULL, 'A additional set of years was added to compensate for the years B.C.'),
(4547, 'Error', 888, '2010-08-02', '03:22:16', 'Reported', 'Windowed mode of the program does not actually change the windows size.', NULL, NULL, NULL),
(4548, 'User', 1024, '2010-07-21', '14:23:32', 'Closed', 'Changing the Year will return the wars from that year, as well as the results from the last year.', 'Barrett50', 'If you search 5 or so years, you have too many things to sort through.', 'System now deletes previous queries before creating new ones.'),
(7, 'User', 2, '2009-06-18', '13:22:11', 'Reported', 'The European war dates are off by a decade each.', 'Billy Rodger', 'The war of 1812 didn''t happen in 1802.', NULL),
(213, 'User', 29, '1994-06-16', '11:23:33', 'Reported', 'The start date of WWII is off.', 'Sarah Putty', 'The official start date of WWII was September 1st.', NULL),
(4549, 'User', 561, '2010-08-25', '10:55:12', 'Closed', 'Napoleon does not show as being in the Battle of Waterloo.', 'TimothyTooth', NULL, 'Update was made.');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `pk` int(11) NOT NULL AUTO_INCREMENT,
  `test1` int(11) NOT NULL,
  `test2` text NOT NULL,
  PRIMARY KEY (`pk`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`pk`, `test1`, `test2`) VALUES
(1, 123123, 'asdsad'),
(9, 123123, 'test'),
(3, 123123, 'asdsad'),
(10, 123123, 'for the empire!'),
(5, 123123, 'asdsad'),
(6, 123123, 'asdsad'),
(7, 123123, 'asdsad'),
(8, 123123, 'asdsad'),
(11, 123123, 'for the empire!'),
(14, 0, 'bomberman');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `password`, `email`, `name`) VALUES
(1, 'jbag', 'capstone', 'capstone@www.com', 'Joey Bagadoughnuts'),
(20, 'AdamSmith', 'adamsmith1', 'SmithA@hotmail.com', 'Adam Smith'),
(21, 'JaneDoes', 'janedoes1', 'DoesJ@gmail.com', 'Jane Does'),
(22, 'LarryKruger', 'larrykruger1', 'KrugerL@aol.com', 'Larry Kruger'),
(23, 'BobbyDerrick', 'bobbyderrick1', 'DerrickB@travel.com', 'Bobby Derrick'),
(24, 'AnneMick', 'annemick1', 'MickA@blarg.com', 'Anne Mick'),
(25, 'MariaLigowski', 'marialigowski1', 'LigowskiM@pole.com', 'Maria Ligowski'),
(26, 'JamesDeBouis', 'jamesdebouis1', 'DeBouisJ@aol.com', 'James DeBouis'),
(27, 'MeganGregor', 'megangregor1', 'GregorM@gmail.com', 'Megan Gregor'),
(28, 'DeanOffer', 'deanoffer1', 'OfferD@dll.com', 'Dean Offer'),
(29, 'TomasLigitt', 'tomasligitt1', 'LigittT@itt-tech.edu', 'Tomas Ligitt');

-- --------------------------------------------------------

--
-- Table structure for table `u_adamsmith`
--

CREATE TABLE IF NOT EXISTS `u_adamsmith` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `u_adamsmith`
--

INSERT INTO `u_adamsmith` (`index`, `projectid`, `groupid`) VALUES
(1, 0, 8),
(2, 19, 0),
(3, 20, 0),
(4, 0, 17),
(5, 21, 0),
(6, 22, 0),
(7, 23, 0);

-- --------------------------------------------------------

--
-- Table structure for table `u_annemick`
--

CREATE TABLE IF NOT EXISTS `u_annemick` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `u_annemick`
--

INSERT INTO `u_annemick` (`index`, `projectid`, `groupid`) VALUES
(1, 0, 13),
(2, 0, 10),
(3, 32, 0),
(4, 27, 0),
(5, 33, 0),
(6, 34, 0),
(8, 41, 0),
(9, 48, 0);

-- --------------------------------------------------------

--
-- Table structure for table `u_bobbyderrick`
--

CREATE TABLE IF NOT EXISTS `u_bobbyderrick` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `u_bobbyderrick`
--

INSERT INTO `u_bobbyderrick` (`index`, `projectid`, `groupid`) VALUES
(1, 0, 11),
(2, 0, 12),
(3, 28, 0),
(4, 29, 0);

-- --------------------------------------------------------

--
-- Table structure for table `u_deanoffer`
--

CREATE TABLE IF NOT EXISTS `u_deanoffer` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `u_deanoffer`
--

INSERT INTO `u_deanoffer` (`index`, `projectid`, `groupid`) VALUES
(1, 0, 17),
(2, 0, 13),
(3, 22, 0),
(4, 32, 0),
(5, 34, 0),
(6, 35, 0);

-- --------------------------------------------------------

--
-- Table structure for table `u_jamesdebouis`
--

CREATE TABLE IF NOT EXISTS `u_jamesdebouis` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `u_jamesdebouis`
--

INSERT INTO `u_jamesdebouis` (`index`, `projectid`, `groupid`) VALUES
(1, 0, 15),
(2, 0, 11),
(3, 38, 0),
(4, 39, 0),
(5, 40, 0);

-- --------------------------------------------------------

--
-- Table structure for table `u_janedoes`
--

CREATE TABLE IF NOT EXISTS `u_janedoes` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `u_janedoes`
--

INSERT INTO `u_janedoes` (`index`, `projectid`, `groupid`) VALUES
(4, 0, 16),
(3, 0, 10),
(5, 24, 0),
(6, 25, 0),
(7, 26, 0),
(8, 27, 0);

-- --------------------------------------------------------

--
-- Table structure for table `u_jbag`
--

CREATE TABLE IF NOT EXISTS `u_jbag` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `u_jbag`
--

INSERT INTO `u_jbag` (`index`, `projectid`, `groupid`) VALUES
(1, 19, 0),
(2, 0, 7),
(4, 20, 0),
(5, 0, 8);

-- --------------------------------------------------------

--
-- Table structure for table `u_larrykruger`
--

CREATE TABLE IF NOT EXISTS `u_larrykruger` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `u_larrykruger`
--

INSERT INTO `u_larrykruger` (`index`, `projectid`, `groupid`) VALUES
(1, 0, 12),
(2, 0, 8),
(3, 30, 0),
(4, 29, 0),
(5, 31, 0),
(6, 19, 0);

-- --------------------------------------------------------

--
-- Table structure for table `u_marialigowski`
--

CREATE TABLE IF NOT EXISTS `u_marialigowski` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `u_marialigowski`
--

INSERT INTO `u_marialigowski` (`index`, `projectid`, `groupid`) VALUES
(1, 0, 14),
(2, 0, 9),
(3, 35, 0),
(4, 36, 0),
(5, 37, 0);

-- --------------------------------------------------------

--
-- Table structure for table `u_megangregor`
--

CREATE TABLE IF NOT EXISTS `u_megangregor` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `u_megangregor`
--

INSERT INTO `u_megangregor` (`index`, `projectid`, `groupid`) VALUES
(1, 0, 16),
(2, 0, 14),
(3, 25, 0),
(4, 37, 0),
(5, 41, 0);

-- --------------------------------------------------------

--
-- Table structure for table `u_tomasligitt`
--

CREATE TABLE IF NOT EXISTS `u_tomasligitt` (
  `index` int(11) NOT NULL AUTO_INCREMENT,
  `projectid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `u_tomasligitt`
--

INSERT INTO `u_tomasligitt` (`index`, `projectid`, `groupid`) VALUES
(1, 0, 9),
(2, 0, 15),
(3, 39, 0),
(4, 42, 0),
(5, 43, 0),
(6, 44, 0);
